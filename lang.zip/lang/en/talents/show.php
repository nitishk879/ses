<?php

return array(
    'hr_char' => 'Human Resource Characteristics',
    'work_location_details' => 'Work Location Details',
    // Oct 10, 2024
    'download' => 'Download',
    'close' => 'Close',
    'no_talents_found' => 'No talents found.',
    'resume_details' => 'Resume Details',
    'search_error' => "There is no result for the criteria you're looking. Please modify your search and change filter to different values.",
    'japanese' => 'Japanese',
    'other' => 'Other'
);
