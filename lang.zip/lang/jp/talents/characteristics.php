<?php

return array(
    "user_support" => "ユーザーサポートの経験がある方",
    "price_negotiable" => "価格交渉可能",
    "full_time" => "フルタイムスタッフを募集中",
    "over_100" => "100名以上のプロジェクト経験がある方",
    "english_exp" => "英語でのビジネス利用経験がある方",
    "consulting_firm" => "コンサルティング会社出身",
    "full_remote" => "完全リモートワークが望ましい",
    "long_term" => "長期希望",
    "leadership" => "リーダーシップ経験",
    "local_project" => "ローカルプロジェクトを募集中",
    "permanent_staff" => "常勤スタッフを募集中",
    "shift_work" => "シフト勤務希望"
);
