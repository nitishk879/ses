<?php

return array(
    'company' => 'Company',
    'company_list' => 'Company List',
    'add_company' => 'Add Company',
    'edit_company' => 'Edit Company',
    'company_name' => 'Company Name',
    'company_address' => 'Company Address',
    'company_phone' => 'Company Phone',
    'company_email' => 'Company Email',
    'company_website' => 'Company Website',
    'company_location' => 'Company location',
    'company_logo' => 'Company Logo',
    'company_introduction' => 'Introduction',
    'company_established' => 'Established',
    'company_capital' => 'Capital',
    'company_total_employees' => 'No. of Employees',
    'dispatch_license' => 'Dispatch License',
    'specialization' => 'Specialized Industry',
    'area_of_expertise' => 'Area of Expertise',
    'representative' => 'Representative',
);
