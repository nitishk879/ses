<?php
return array(
    "user_support" => "Experience in user support",
    "price_negotiable" => "Price negotiable",
    "full_time" => "Full-time staff available",
    "over_100" => "Experience in projects with over 100 people",
    "english_exp" => "English business use experience",
    "consulting_firm" => "From a consulting firm",
    "full_remote" => "Full remote work preferred",
    "long_term" => "Long-term hope",
    "leadership" => "Leadership experience",
    "local_project" => "Local projects available",
    "permanent_staff" => "Some permanent staff available",
    "shift_work" => "Shift work request"
);
