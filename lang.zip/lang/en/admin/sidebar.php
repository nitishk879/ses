<?php

return array(
    'dashboard' => 'Dashboard',
    'messages' => 'Messages',
    'company_profile' => 'Company Profile',
    'all_applicants' => 'All Applicants',
    'applicants' => 'Applicants',
    'job_listings' => 'Job Listings',
    'my_schedule' => 'My Schedule',
);
