<?php
return array(
    'dashboard' => 'Dashboard',
    'new_candidates_to_review' => 'New Candidates To Review',
    'message_received' => 'Message Received',
    'profile_matching' => 'Profile Matching :profile',
    'job_statistics' => 'Job Statistics',
    'showing_job_statistics' => 'Showing Job Statistics',
    'week' => 'Week',
    'month' => 'Month',
    'year' => 'Year',
    'applicants' => 'Applicants',
    'application_summary' => 'Application Summary',
    'job_openings' => 'Job Openings',
    'job_opened' => 'Job Opened',
);
