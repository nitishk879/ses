<?php
// oct 9th, 2024
return array(
    'apply_now' => 'Apply now',
    'cancel' => 'Cancel',
    'save' => 'Save',
    'apply_later' => 'Apply later'
);
